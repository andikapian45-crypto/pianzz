/* 

=========================================================================

  🕊 Credits By Vynxx
    wa.me/6285714017585
    Saluran Info Script : https://whatsapp.com/channel/0029Vb9ghly6GcGM2ngCEk00
   
=========================================================================

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//======================================================Settings Bot=========================================================================//
global.owner = '628982103547'
global.versi = version
global.namaOwner = "Vynxx"
global.packname = 'Bot WhatsApp'
global.botname = '𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊'
global.botname2 = '𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊'

//=====================================//
global.linkOwner = "https://wa.me/62895320985817"
global.linkGrup = "https://chat.whatsapp.com/Edjc6Og4FIWL1FKh58qHkV"

//=====================================//
global.delayJpm = 3500
global.delayPushkontak = 6000

//=====================================//
global.linkSaluran = "https://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V"
global.idSaluran = "120363409362506610@newsletter"
global.namaSaluran = "Vynxx"

//=====================================//
global.dana = "-" //Isi aja payment lu
global.ovo = "-"
global.gopay = "-"

//=====================================//
global.image = {
menu: "https://img1.pixhost.to/images/6126/605494781_vynx.jpg", //Ubah aja jdi image lu
reply: "https://img1.pixhost.to/images/6126/605494781_vynx.jpg", 
logo: "https://img1.pixhost.to/images/6126/605494781_vynx.jpg", 
qris: "https://img1.pixhost.to/images/5577/596061743_tamaofficial.jpg"//Ubah aja jdi foto qris lu
}

//=====================================//
global.mess = {
	owner: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Bang Vynx 🕊
╰━━━━━━━━━━━━━━━━━⬣`,
	admin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Admin Group King ⚠
╰━━━━━━━━━━━━━━━━━⬣`,
	botAdmin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Bot Harus Jadi Admin Terlebih dahulu King 🌛
╰━━━━━━━━━━━━━━━━━⬣`,
	group: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya berlaku di Group King 🌛
╰━━━━━━━━━━━━━━━━━⬣`,
	private: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya dapat di lakukan di private cht King 🌛
╰━━━━━━━━━━━━━━━━━⬣`,
	prem: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya Untuk Orang Pilihan Bang Vynx 🕊
╰━━━━━━━━━━━━━━━━━⬣`,
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})